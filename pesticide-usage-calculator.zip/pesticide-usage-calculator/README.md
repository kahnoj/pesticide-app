# Pesticide usage calculator

A Pen created on CodePen.

Original URL: [https://codepen.io/Mohsen-Daneshmand-Vaziri/pen/WbvVoWb](https://codepen.io/Mohsen-Daneshmand-Vaziri/pen/WbvVoWb).

